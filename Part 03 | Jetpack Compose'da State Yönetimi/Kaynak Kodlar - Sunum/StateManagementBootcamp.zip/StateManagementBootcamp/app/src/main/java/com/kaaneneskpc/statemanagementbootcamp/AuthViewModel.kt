package com.kaaneneskpc.statemanagementbootcamp

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class AuthViewModel @Inject constructor() : ViewModel() {

    var username by mutableStateOf("")
    var password by mutableStateOf("")
    var isLoading by mutableStateOf(false)

    fun updateUsername(value: String) { username = value }
    fun updatePassword(value: String) { password = value }
    private fun updateIsLoading(value: Boolean) { isLoading = value }

    fun signIn(
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {
        viewModelScope.launch {
            updateIsLoading(true)
            delay(2000) // Simulate network delay
            updateIsLoading(false)
            if (username == "test" && password == "123") {
                onSuccess()
            } else {
                onError("Invalid credentials")
            }
        }
    }
}